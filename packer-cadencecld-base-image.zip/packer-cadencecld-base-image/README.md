# packer-cadencecld-rhel8-base-image
This is the repo for Cloud RHEL 8 Base Image

