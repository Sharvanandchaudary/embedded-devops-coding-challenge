#!/bin/bash
####
## MUNGE v0.5.15 installation for SLURM v24.05.0
## by tarikk@cadence.com
## do not change munge UID/GID
####
if [ -f /etc/nsswitch.conf ]; then
    sed -i '/^passwd:/ s/ldap//' /etc/nsswitch.conf
    sed -i '/^group:/ s/ldap//' /etc/nsswitch.conf
    sed -i '/^shadow:/ s/ldap//' /etc/nsswitch.conf

    # Restart nslcd and nscd services
    systemctl restart nslcd
    systemctl restart nscd
fi

# Setup User & Group
groupadd -g 9999 munge
useradd munge -u 10000 -g 9999 -m -s /sbin/nologin

mkdir -p /run/munge
mkdir -p /etc/munge
mkdir -p /var/log/munge/
mkdir -p /var/lib/munge

# Build & install munge
cd /tmp
curl -k -o "munge-0.5.15.tar.xz" -X "GET" "https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/DRM/munge-0.5.15.tar.xz"
tar -xvf munge-0.5.15.tar.xz

cd munge-0.5.15
./configure --prefix=/usr --sysconfdir=/etc --localstatedir=/var --runstatedir=/run --libdir=/usr/lib64
make
make check
make install

# Create munge key
dd if=/dev/urandom bs=1 count=1024 > /etc/munge/munge.key

# Setup daemon
cat > /etc/sysconfig/munge <<EOF
# MUNGE configuration

# Pass additional command-line options to munged.
OPTIONS="--key-file=/etc/munge/munge.key --num-threads=2"
EOF

cat > /lib/systemd/system/munge.service <<EOF
[Unit]
Description=MUNGE authentication service
Documentation=man:munged(8)
Wants=network-online.target
After=network-online.target
After=time-sync.target

[Service]
Type=forking
EnvironmentFile=-/etc/sysconfig/munge
ExecStart=/usr/sbin/munged $OPTIONS
PIDFile=/run/munge/munged.pid
RuntimeDirectory=munge
RuntimeDirectoryMode=0755
User=munge
Group=munge
Restart=on-abort

[Install]
WantedBy=multi-user.target
EOF

# Set permissions
chown -R munge:munge /run/munge
chmod 755 /run/munge/
chown -R munge:munge /etc/munge
chown -R munge:munge /var/log/munge/
chmod 700 /var/log/munge/
chown -R munge:munge /var/lib/munge
chown munge:munge /etc/sysconfig/munge
chown munge:munge /etc/munge/munge.key
chmod 700 /etc/munge/munge.key

# Enable service
systemctl daemon-reload
# systemctl enable munge
# systemctl start munge
# systemctl status munge