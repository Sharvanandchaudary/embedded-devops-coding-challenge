#!/bin/bash
 
cd /opt
curl -k -o "libhw.tar" -X "GET" "https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/DRM/libhw.tar"
tar -xvf libhw.tar -C /lib64
