export JAVA_HOME=/usr/java/default
export PATH=$PATH:$JAVA_HOME/bin
export MANPATH=$MANPATH:$JAVA_HOME/man
