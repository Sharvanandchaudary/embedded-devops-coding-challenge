#!/bin/bash

cd /tmp
curl -k -o "tcp_wrappers-libs-7.6-96.el8.x86_64.rpm" -X "GET" "https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/Tools/tcp_wrappers-libs-7.6-96.el8.x86_64.rpm"
yum install tcp_wrappers-libs-7.6-96.el8.x86_64.rpm -y >/dev/null 2>&1

cd /tmp
rm -rf tcp_wrappers-libs-7.6-96.el8.x86_64.rpm
