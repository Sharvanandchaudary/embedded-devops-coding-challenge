yum install nfs-utils bash tcsh ksh tcl vim unzip mlocate chrony lsof glibc glibc.i686 glibc-devel glibc-devel.i686  libicu-devel motif motif.i686 mesa-libGL mesa-libGL.i686 mesa-libGLU mesa-libGLU.i686 gdb libXp libXp.i686 libpng libpng.i686 libpng12 libpng12.i686 libXt libXft apr apr-util  gd gd-devel gdbm gdbm-devel libotf libjpeg-turbo libjpeg-turbo.i686 libtirpc   libXScrnSaver libXrender expat expat.i686 perf kernel kernel-devel kernel-headers kernel-abi-whitelists xorg-x11-server-Xvfb xorg-x11-fonts-* xorg-x11-fonts-misc xorg-x11-fonts-Type1 xorg-x11-fonts-75dpi xorg-x11-fonts-100dpi xorg-x11-fonts-ISO8859-1-100dpi xorg-x11-fonts-ISO8859-1-75dpi xorg-x11-font-utils xorg-x11-utils gcc bind-utils hwloc openldap openldap-clients nss-pam-ldapd sendmail sendmail-cf m4 wget redhat-lsb-core.i686 redhat-lsb-core redhat-lsb
 
yum install nfs-utils redhat-lsb environment-modules pcre-devel autofs nss-pam-ldapd sssd-client openldap openldap-devel openldap-clients pam pam_ldap unzip zip chrony mariadb postfix cyrus-sasl-plain cyrus-sasl-devel libvirt java-1.8.0-openjdk java-1.8.0-openjdk-headless java-1.8.0-openjdk-devel
 
yum install xterm libXScrnSaver libXp tk tk-devel tcl tcl-devel
 
yum install redhat-lsb.x86_64 glibc.x86_64 glibc.i686 elfutils-libelf.x86_64 elfutils-libelf.i686 mesa-libGL.x86_64 mesa-libGL.i686 mesa-libGLU.x86_64 mesa-libGLU.i686 motif.x86_64 motif.i686 libXp.x86_64 libXp.i686 libpng.x86_64 libpng.i686 libjpeg-turbo.x86_64 libjpeg-turbo.i686 expat.x86_64 expat.i686 glibc-devel.x86_64 glibc-devel.i686 libdb apr-util.x86_64 apr.x86_64
 
# install chef
curl -k -o "chef-12.16.42-1.el6.x86_64.rpm" -X "GET" "https://packages.chef.io/files/stable/chef/12.16.42/el/6/chef-12.16.42-1.el6.x86_64.rpm"
yum install chef-12.16.42-1.el6.x86_64.rpm -y >/dev/null 2>&1 
 
# install miniconda if python3 is not installed in AMI
bash {{remote_tool_path}}/tools/Miniconda3-latest-Linux-x86_64.sh -b -p /opt/miniconda3;
ln -s /opt/miniconda3/bin/python3.* /usr/bin/python3;
ln -s /opt/miniconda3/bin/pip /usr/bin/pip3;
# install boto3 if reqruied
/usr/bin/pip3 install boto3

## aws cli installtion 

curl -k -o "awscliv2.zip" -X "GET" "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip"
unzip awscliv2.zip
./aws/install
 
# install aws cli
##https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
 
#update/create /etc/profile.d/java.sh
 
#vim /etc/profile.d/java.sh
#export JAVA_HOME=/usr/java/default
#export PATH=$PATH:$JAVA_HOME/bin
#export MANPATH=$MANPATH:$JAVA_HOME/man
