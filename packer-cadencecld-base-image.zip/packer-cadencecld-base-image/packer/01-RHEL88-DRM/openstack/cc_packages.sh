#!/bin/bash
set -euxo pipefail

yum install python3.11-devel -y >/dev/null 2>&1
yum install python3.11-pip -y >/dev/null 2>&1

sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.11 20000
sudo update-alternatives --set python3 /usr/bin/python3.11
echo "[info] python version is set 3.11"

cd /tmp
curl -k -o "openstack-cli.tar.gz" -X "GET" "https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/Tools/openstack-cli.tar.gz"
tar -xvf openstack-cli.tar.gz
python3 -V
pip3.11 install -q -r openstack-cli/requirements.txt --no-index --find-links openstack-cli

/usr/local/bin/swift --version


cd /tmp
curl -k -o "tcp_wrappers-libs-7.6-96.el8.x86_64.rpm" -X "GET" "https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/Tools/tcp_wrappers-libs-7.6-96.el8.x86_64.rpm"
yum install tcp_wrappers-libs-7.6-96.el8.x86_64.rpm -y >/dev/null 2>&1

cd /tmp
rm -rf openstack-cli
rm -rf tcp_wrappers-libs-7.6-96.el8.x86_64.rpm
