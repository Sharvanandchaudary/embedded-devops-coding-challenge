#!/bin/bash -euxo pipefail

yum install python3.11-devel -y >/dev/null 2>&1
yum install python3.11-pip -y >/dev/null 2>&1
sudo update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.11 20000
#sudo update-alternatives --set python3 /usr/bin/python3.11

cd /tmp
wget --no-check-certificate https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/Tools/openstack-cli.tar.gz >/dev/null 2>&1
tar -xvf openstack-cli.tar.gz
python3 -V
#pip3.11 install -q -r openstack-cli/requirements.txt --no-index --find-links openstack-cli
pip3.11 install python-swiftclient
pip3.11 install python-openstackclient

swift --version

#wget --no-check-certificate https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/Tools/tcp_wrappers-libs-7.6-96.el8.x86_64.rpm >/dev/null 2>&1
#yum install tcp_wrappers-libs-7.6-96.el8.x86_64.rpm -y >/dev/null 2>&1

wget --no-check-certificate https://artifacts.cadence.com/repository/cadence-cloud-infra-repo/cumulus/openlogic-openjdk-11.0.18%2B10-linux-x64.tar.gz -O openlogic-openjdk-11.0.18-10-linux-x64.tar.gz >/dev/null 2>&1
mkdir -p /opt/java
tar -zxf openlogic-openjdk-11.0.18-10-linux-x64.tar.gz -C /opt/java
cd /opt/java
ln -s /opt/java/openlogic-openjdk-11.0.18+10-linux-x64/ /opt/java/current
for file in /opt/java/current/bin/*
do
   if [ -x $file ]
   then
      filename=`basename $file`
      sudo update-alternatives --install /usr/bin/$filename $filename $file 20000
      sudo update-alternatives --set $filename $file
   fi
done

cd /tmp
rm -fr /tmp/openstack-cli
rm -fr tcp_wrappers-libs-7.6-96.el8.x86_64.rpm
rm -fr openlogic-openjdk-11.0.18-10-linux-x64.tar.gz

echo "python version is set 3.11"


